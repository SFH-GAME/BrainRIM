<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>2048</title>
	<link href="https://fonts.googleapis.com/css2?family=Balsamiq+Sans&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="/pages/Games/Chill/math3/css/math3.css">    
</head>
<body>
<div class="game-container">
      <div class="bird"></div>
    </div>
   <script src="/pages/Games/Chill/math3/js/math3.js"></script>  
</body>
</html>